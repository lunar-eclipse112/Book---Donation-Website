# 📚 The Literary Shelf

> A virtual library platform for school students to donate and borrow books.
> *Initiated by Rupali and Sarayu of Class 11B*

## Project Structure

```
literary-shelf/
├── api/
│   └── index.py          # Flask app (Vercel entry point)
├── static/
│   └── css/main.css      # Stylesheet (also inlined in base.html)
├── templates/
│   ├── base.html         # Base layout with inlined CSS
│   ├── index.html        # Homepage
│   ├── browse.html       # Book catalog with filters
│   ├── donate.html       # Donation form
│   ├── request.html      # Wishlist
│   ├── profile.html      # User profile
│   ├── about.html        # About Us
│   ├── auth.html         # Login / Sign Up
│   └── 404.html          # 404 page
├── requirements.txt      # flask==3.1.0
├── vercel.json           # Vercel config
└── README.md
```

## Local Development

```bash
pip install flask
python api/index.py
# → http://localhost:5000
```

## Deploy to Vercel

See **DEPLOYMENT.md** for full instructions. Quick start:

### Option 1 — CLI
```bash
npm i -g vercel
vercel          # preview
vercel --prod   # production
```

### Option 2 — GitHub
1. Push this repo to GitHub
2. Go to vercel.com → New Project → Import repo
3. Vercel auto-detects `vercel.json` → click **Deploy**


## Connect Supabase (Production)

Replace the sample `BOOKS`/`WISHLIST` data in `api/index.py` with Supabase queries:

```python
from supabase import create_client
supabase = create_client(os.environ["VITE_SUPABASE_URL"], os.environ["VITE_SUPABASE_PUBLISHABLE_KEY"])
books = supabase.table("books").select("*").eq("is_available", True).execute().data
```

Add env vars in Vercel dashboard: `SUPABASE_URL` and `SUPABASE_KEY`.
