import os
from flask import Flask, render_template, request, redirect, url_for, flash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)

app = Flask(
    __name__,
    template_folder=os.path.join(ROOT_DIR, "templates"),
    static_folder=os.path.join(ROOT_DIR, "static"),
    static_url_path="/static",
)
app.secret_key = "literary-shelf-secret"

# ── Sample data (replace with Supabase in production) ──────────────────────

BOOKS = [
    {"id": 1, "title": "The Alchemist", "author": "Paulo Coelho", "subject": "Fiction", "condition": "Good", "donor": "Aarav S.", "available": True, "notes": "Lightly read, pages intact."},
    {"id": 2, "title": "Wings of Fire", "author": "A.P.J. Abdul Kalam", "subject": "Biography", "condition": "New", "donor": "Priya M.", "available": True, "notes": "Gift copy, never opened."},
    {"id": 3, "title": "NCERT Chemistry Pt. 1", "author": "NCERT", "subject": "Science", "condition": "Fair", "donor": "Rohan K.", "available": True, "notes": "Some pencil marks, answers erased."},
    {"id": 4, "title": "To Kill a Mockingbird", "author": "Harper Lee", "subject": "Fiction", "condition": "Good", "donor": "Sneha R.", "available": False, "notes": "Classic condition."},
    {"id": 5, "title": "Sapiens", "author": "Yuval Noah Harari", "subject": "History", "condition": "New", "donor": "Aditya V.", "available": True, "notes": "Barely touched."},
    {"id": 6, "title": "Mathematics Textbook XI", "author": "NCERT", "subject": "Mathematics", "condition": "Fair", "donor": "Meera P.", "available": True, "notes": "Used but complete."},
]

WISHLIST = [
    {"id": 1, "title": "Atomic Habits", "author": "James Clear", "subject": "Self-Help", "requester": "Class 11A", "notes": "For our study group."},
    {"id": 2, "title": "Rich Dad Poor Dad", "author": "Robert Kiyosaki", "subject": "Finance", "requester": "Class 12B", "notes": "Any condition accepted."},
    {"id": 3, "title": "NCERT Biology XII", "author": "NCERT", "subject": "Science", "requester": "Class 12A", "notes": "Urgently needed for boards prep."},
]

SUBJECTS = sorted(set(b["subject"] for b in BOOKS))
CONDITIONS = ["New", "Good", "Fair", "Worn"]

STATS = {
    "books_available": sum(1 for b in BOOKS if b["available"]),
    "total_donated": len(BOOKS),
    "students": 48,
    "wishlist": len(WISHLIST),
}

SARA_TIPS = {
    "browse": "Use the filters to find books by subject or condition. Green badge = available now!",
    "donate": "Even worn books are welcome! Someone will appreciate it.",
    "request": "Can't find your book? Add it to the wishlist — a classmate might donate it.",
    "profile": "Keep your class section updated so donors can reach you faster.",
}


# ── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    featured = [b for b in BOOKS if b["available"]][:3]
    return render_template("index.html", stats=STATS, featured=featured)


@app.route("/browse")
def browse():
    q = request.args.get("q", "").lower()
    subject = request.args.get("subject", "")
    condition = request.args.get("condition", "")
    avail_only = request.args.get("available", "")

    books = BOOKS
    if q:
        books = [b for b in books if q in b["title"].lower() or q in b["author"].lower()]
    if subject:
        books = [b for b in books if b["subject"] == subject]
    if condition:
        books = [b for b in books if b["condition"] == condition]
    if avail_only:
        books = [b for b in books if b["available"]]

    return render_template(
        "browse.html",
        books=books,
        subjects=SUBJECTS,
        conditions=CONDITIONS,
        tip=SARA_TIPS["browse"],
        q=q, subject=subject, condition=condition, avail_only=avail_only,
    )


@app.route("/donate", methods=["GET", "POST"])
def donate():
    if request.method == "POST":
        flash("Thank you! Your book has been listed. A librarian will verify it shortly.", "success")
        return redirect(url_for("donate"))
    return render_template("donate.html", subjects=SUBJECTS, conditions=CONDITIONS, tip=SARA_TIPS["donate"])


@app.route("/request", methods=["GET", "POST"])
def book_request():
    if request.method == "POST":
        flash("Your request has been added to the wishlist!", "success")
        return redirect(url_for("book_request"))
    return render_template("request.html", wishlist=WISHLIST, subjects=SUBJECTS, tip=SARA_TIPS["request"])


@app.route("/profile")
def profile():
    user_books = BOOKS[:2]
    return render_template("profile.html", books=user_books, tip=SARA_TIPS["profile"])


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/auth")
def auth():
    return render_template("auth.html")


if __name__ == "__main__":
    app.run(debug=True)
