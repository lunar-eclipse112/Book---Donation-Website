# Deploying The Literary Shelf to Vercel

This is a Flask (WSGI) app. The entry point is `api/index.py`, which exports a
Flask instance named `app`. Vercel's Python runtime serves it as a serverless
function, and `vercel.json` routes every request (including `/static/*`) to it.

## Project layout
```
literary-shelf/
├── api/index.py        # Flask app (Vercel entry point, exports `app`)
├── templates/          # Jinja2 templates
├── static/             # CSS / assets (served via Flask static_folder)
├── requirements.txt    # Python dependencies
└── vercel.json         # Vercel build + routing config
```

## Prerequisites
- A free [Vercel account](https://vercel.com).
- (CLI option) Node.js installed for `npm`.
- (Local run) Python 3.9+.

## Run locally
```bash
pip install -r requirements.txt
python api/index.py
# → http://localhost:5000
```

## Deploy — Option A: Vercel CLI
```bash
npm i -g vercel       # install the CLI once
vercel                # from the project root: preview deploy (follow prompts)
vercel --prod         # promote to production
```

## Deploy — Option B: GitHub import
1. Push this project to a GitHub repository.
2. Go to vercel.com → **New Project** → **Import** the repo.
3. Vercel auto-detects `vercel.json` (Python runtime). Click **Deploy**.

## Notes
- **Static files**: all routes, including `/static/*`, are forwarded to the
  Flask app, which serves static assets via its configured `static_folder`.
- **Python version**: set it (optional) by adding a `runtime` in `vercel.json`
  builds config or a `Pipfile`/`.python-version`; the default runtime works here.
- **Environment variables** (only if you switch the sample data to Supabase):
  add `SUPABASE_URL` and `SUPABASE_KEY` under
  Vercel → Project → Settings → Environment Variables, and add the
  `supabase` package to `requirements.txt`.
